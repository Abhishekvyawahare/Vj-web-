<?php

if(isset($_POST['btn']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$message=$_POST['message'];
}

$cn=mysqli_connect("localhost","root","");
$db=mysqli_select_db($cn,"vj");

$q="insert into enq values('','$name','$email','$mobile','$message')";
mysqli_query($cn,$q);
mysqli_close($cn);
echo " <script> 
alert('thanks for showing intrest! contact you soon regard VJ');
window.location.href='index.html';

</script>";


?>